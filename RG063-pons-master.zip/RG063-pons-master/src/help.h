#ifndef HELP_H
#define HELP_H

void draw_grid(int HALF_GRID_SIZE);
void coordsys(void);
void draw_road(int Xp, int Yp, int Xr, int Yr);
void draw_scene(void);
void draw_point(float x, float y);

#endif
